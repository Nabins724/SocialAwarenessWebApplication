
	function register() {
    // Get form values
    const fullname = document.getElementById('fullname').value;
    const phone = document.getElementById('phone').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    // Basic validation
    if (fullname === "") {
        alert("Please enter your full name.");
        return;
    }
    if (phone === "" || phone.length < 10) {
        alert("Please enter a valid phone number.");
        return;
    }
    if (email === "" || !email.includes("@")) {
        alert("Please enter a valid email.");
        return;
    }
    if (password === "" || password.length < 6) {
        alert("Password must be at least 6 characters long.");
        return;
    }

    // Display success message
    alert("Registration successful!");
    document.getElementById('registrationForm').reset(); // Clear form after registration
}

function resetForm() {
    document.getElementById('registrationForm').reset(); // Clear form fields
}
